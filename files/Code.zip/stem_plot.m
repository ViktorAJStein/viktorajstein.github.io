clc;    % Clear the command window.
close all;  % Close all figures (except those of imtool.)
clear;  % Erase all existing variables. Or clearvars if you want.

% periodic spike train
figure
tspikes = [0.6472, 0.6337, 0.3846, 0.4187];
X = cos(2*pi*tspikes);
Y = sin(2*pi*tspikes);
Z = [15.4038, 2.0139, 6.9134, 6.0873]; % amplitudes
stem3(X,Y,Z,'*k','LineWidth', 2)
set(gca,'XTick',[])
set(gca,'YTick',[])
hold on
th = 0:pi/50:2*pi;
xunit = cos(th);
yunit = sin(th);
plot(xunit, yunit, 'k');
labels = [0, 1/4, 1/2, 3/4];
plot(cos(2*pi*labels),sin(2*pi*labels),'|b')
directions = ['N', 'S', 'N', 'S'];
for k=1:length(labels)
    labelpoints(cos(2*pi*labels(k)),sin(2*pi*labels(k)),labels(k), directions(k), 0.3, 1)
end
leg = legend('$x$', '', '', 'Interpreter', 'latex', 'Location', 'North');
set(leg,'Box','off')

% hold off

% low resolution signal = convolution of true signal with Dirichlet kernel

n = 10000;
hold on
t = linspace(0, 2*pi, n);
f = 5;
low_freq = zeros(1, n);

for k=1:length(tspikes)
   aux_sinc = Z(k)*sin((f + 1/2).*(t - tspikes(k)))./(2.*pi.*sin((t - tspikes(k))/2));
   low_freq = low_freq + aux_sinc; 
end
X1 = cos(t);
Y1 = sin(t);
plot3(X1, Y1, low_freq,'LineWidth', 2, 'color', '#8C001A')
leg1 = legend('$x$', '', '', '$x_{\mathrm{low}}$' ,'Interpreter','latex', 'Location', 'N');
set(leg1,'Box','off')
hold off