clear;
clc;
close all;

c =[6.9361, -2.3162];
fc = 5;
tau = [0.0233, 0.4830];
r = length(tau);

j = -10:10;
s = zeros(length(j), 1);
for m=1:length(j)
    for k=1:r
        s(m) = s(m) + c(k)*exp(- 2 * pi * 1i * tau(k) * (m - 10));
    end
end
t = s;
t(1:5) = 0;
t(17:21) = 0;
hold on
stem(j, real(s), 'k*', 'LineWidth', 2)
%stem(j, real(t), 'r*', 'LineWidth', 2, 'color', '#8C001A')
hold off
leg = legend('$\Re(\widehat{x})$', 'Interpreter', 'LaTeX'); % '$\Re(\widehat{x_{\textrm{low}}})$'
set(leg,'Box','off')
xticks([-10, - 5, -1, 0, 1, 5, 10])
xticklabels({-10, '- f', -1, 0, 1, 'f', 10})