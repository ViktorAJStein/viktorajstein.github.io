clear;
clc;
close all;

f = 5;
figure
n = 10;
j = -n:n;
s = zeros(length(j), 1);
s(n+1-f:f+n+1) = 1;
hold on
stem(j, real(s), 'k*', 'LineWidth', 2, 'color', '#8C001A')
hold off
leg = legend('$\widehat{g}$', 'Interpreter', 'LaTeX');
set(leg,'Box','off')
xticks([-n, - f, -1, 0, 1, f, n])
yticks([0 1])
xticklabels({-n, '- f', -1, 0, 1, 'f', n})
pbaspect([1 1 1])
leg.FontSize = 14;
leg.Title.String = ['f = ' num2str(f)];
n = ['g_hat_' num2str(f) '.pdf'];
saveas(gcf, n);
