% 1D superres
clc;    % Clear the command window.
close all;  % Close all figures (except those of imtool.)
clear;  % Erase all existing variables. Or clearvars if you want.

% fix randomness
rng('default')
s = rng;

N = 100; % image size
M = 2; % number of pixels to be active
f = zeros(1, N);
 
idx = randperm(N);
idx = idx(1:M);
f(idx) = 1 + .5*rand(1, M);

%% plot Fourier transform of image
F = fft2(f);
G = F;
% kill high frequencies
G(abs(G) > .9) = 0;
tiledlayout(2,3);
nexttile
imshow(f,'InitialMagnification','fit')

% nexttile
% imshow(real(F),'InitialMagnification','fit');
% 
% nexttile
% imshow(imag(F),'InitialMagnification','fit');
% 
nexttile
imshow(abs(F),'InitialMagnification','fit');

nexttile
imshow(abs(G),'InitialMagnification','fit');

nexttile
nexttile
imshow(abs(ifft2(F)),'InitialMagnification','fit');

nexttile
imshow(abs(ifft2(G)),[],'InitialMagnification','fit');

blurry_image = real(ifft2(G));
figure
imshow(abs(ifft2(G)),[],'InitialMagnification','fit');
figure
imshow(blurry_image,[],'InitialMagnification','fit');
