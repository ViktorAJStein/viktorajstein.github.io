% random seed
rng('default')
s = rng;

z = zeros(1, 100);
z(45:47)=rand(1,3);
z(87:91)=rand(1,5);
imshow(z)
cb = colorbar; 
set(cb,'position',[.69 .62 .005 .05])
% arguments are [xposition yposition width height].

w = zeros(1, 500);
w(225:227)=rand(1,3);
w(435:439)=rand(1,5);
imshow(w)
cb2 = colorbar; 
set(cb2,'position',[.87 .62 .005 .025])