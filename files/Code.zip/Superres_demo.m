% Try some actual superresolution
clc;    % Clear the command window.
close all;  % Close all figures (except those of imtool.)
clear;  % Erase all existing variables. Or clearvars if you want.

% myImage_RGB =  imread('Flourescent.jpeg');
myImage_RGB =  imread('2.png');
% imshow(myImage_RGB)
myImage_BW = rgb2gray(myImage_RGB);
figure
imshow(myImage_BW)
colorbar;
FT = fft2(myImage_BW);
FT_real = real(fft2(myImage_BW)); % real part of Fourier transform
figure
imshow(FT_real)
colorbar;

% Kill high frequenies
FT(abs(FT) > 1024) = 0;
figure
imshow(real(FT))
colorbar;

% transform back
low_freq = ifft2(FT);
figure
imshow(low_freq)
colorbar;