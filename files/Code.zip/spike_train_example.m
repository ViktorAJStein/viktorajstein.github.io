% Try some actual superresolution
clc;    % Clear the command window.
close all;  % Close all figures (except those of imtool.)
clear;  % Erase all existing variables. Or clearvars if you want.

% fix randomness
rng('default')
s = rng;

% N = 100; % image size
% M = 2; % number of pixels to be active
% f = zeros(N, N);
% f = f(:); % flatten f
% 
% idx = randperm(size(f,1));
% idx = idx(1:M);
% f(idx,:) = 1 + .5*rand(1, M); % random values from (1, 3/2)
% % and reshape back
% f = reshape(f, [N N]);

% random seed
rng('default')
s = rng;

f = zeros(100,100);
f(15:19,23:27) = rand(5,5)./2 + 0.5; % random numbers between 0.5 and 1
f(30:32,22:24) = rand(3,3)./2 + 0.5;

%g = imread('2.png');
%f = 1/255*double(rgb2gray(g));

%% plot Fourier transform of image
F = fft2(f);
G = F;
% maximum absolute frequency
m = max(abs(G), [],'all');
% normalise G so that max(|G|) = 1.
G = 1/m*G;
% kill 50% of highest frequencies
G(abs(G) > .5) = 0;


figure
imshow(f,[],'InitialMagnification','fit')
%title('original image')

figure
imshow(abs(F),'InitialMagnification','fit');
colorbar;
title('absolute Fourier transform of original')


figure
imshow(abs(G),'InitialMagnification','fit');
colorbar;
title('low-freq Fourier transform')

figure
imshow(abs(ifft2(F)),'InitialMagnification','fit');
colorbar;
title('inverse Fourier transform of Fourier transform of original = original')

figure
imshow(abs(ifft2(G)),[],'InitialMagnification','fit');
%title('inverse Fourier transform of low-freq version')