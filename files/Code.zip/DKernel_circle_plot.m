% some plot
f = 5;
n = 1000;
figure
theta = linspace(0, 2*pi, n);
X = cos(theta);
Y = sin(theta);
Z = sin((f + 1/2)*theta)./(2*pi*sin(theta/2));
Z(n) = (2*f + 1) / (2*pi); % correct for the value of 2 pi
plot3(X,Y,Z,'color', '#8C001A', 'LineWidth', 2);
set(gca,'XTick',[])
set(gca,'YTick',[])
axis([-1 1 -1 1 -0.5 2.5])
grid on
hold on
th = 0:pi/50:2*pi;
xunit = cos(th);
yunit = sin(th);
plot(xunit, yunit, 'k');
labels = [0, 1/4, 1/2, 3/4];
plot(cos(2*pi*labels),sin(2*pi*labels),'|b')
leg1 = legend('g', '', '', 'Location', 'N');
set(leg1,'Box','off')
leg1.FontSize = 14;
leg1.Title.String = 'f = 5';
directions = ['N', 'S', 'N', 'S'];
for k=1:length(labels)
    labelpoints(cos(2*pi*labels(k)),sin(2*pi*labels(k)),labels(k), directions(k), 0.3, 1)
end
view([-57.881215469613259,16.055607476635505]);


